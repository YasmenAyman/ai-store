import React from 'react';
import Form from './Form';

export default function Create() {
    return <Form />;
}
