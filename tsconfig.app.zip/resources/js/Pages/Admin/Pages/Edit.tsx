import React from 'react';
import Form from './Form';

export default function Edit({ page }) {
    return <Form page={page} />;
}
