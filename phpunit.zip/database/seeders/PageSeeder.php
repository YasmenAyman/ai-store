<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageSeeder extends Seeder
{
    public function run(): void
    {
        Page::updateOrCreate(
            ['slug' => 'about'],
            [
                'title' => 'About Us',
                'is_active' => true,
                'content' => [
                    'hero_bg' => '/assets/about-hero.jpg',
                    'hero_title' => 'Our Story',
                    'hero_title_ar' => 'قصتنا',
                    'hero_subtitle' => 'Crafted with passion, inspired by nature',
                    'hero_subtitle_ar' => 'صُنعت بشغف، مستوحاة من الطبيعة',
                    'intro_text' => 'At Lumière, we believe in the transformative power of scent. Each candle is hand-poured with premium soy wax and infused with carefully curated fragrances that evoke warmth, comfort, and elegance. Our perfumes are crafted by master perfumers using the finest natural ingredients from around the world.',
                    'intro_text_ar' => 'في Lumière، نؤمن بالقوة التحويلية للرائحة. كل شمعة يتم صبها يدوياً بشمع الصويا الفاخر وممزوجة بعطور منسقة بعناية تثير الدفء والراحة والأناقة. يتم تصنيع عطورنا من قبل خبراء العطور باستخدام أفضل المكونات الطبيعية من جميع أنحاء العالم.',
                    'mission_title' => 'Our Mission',
                    'mission_title_ar' => 'مهمتنا',
                    'mission_text' => 'To create exceptional fragrances that bring joy and serenity to every home, while maintaining our commitment to sustainability and artisanal craftsmanship.',
                    'mission_text_ar' => 'إنشاء روائح استثنائية تجلب الفرح والصفاء لكل منزل، مع الحفاظ على التزامنا بالاستدامة والحرفية اليدوية.',
                    'values_title' => 'Our Values',
                    'values_title_ar' => 'قيمنا',
                    'value1_title' => 'Premium Quality',
                    'value1_title_ar' => 'جودة ممتازة',
                    'value1_desc' => 'Only the finest natural ingredients',
                    'value1_desc_ar' => 'فقط أفضل المكونات الطبيعية',
                    'value2_title' => 'Sustainable',
                    'value2_title_ar' => 'مستدام',
                    'value2_desc' => 'Eco-friendly materials and practices',
                    'value2_desc_ar' => 'مواد وممارسات صديقة للبيئة',
                    'value3_title' => 'Handcrafted',
                    'value3_title_ar' => 'صنع يدوياً',
                    'value3_desc' => 'Each piece made with care and attention',
                    'value3_desc_ar' => 'كل قطعة مصنوعة بعناية واهتمام',
                ]
            ]
        );

        Page::updateOrCreate(
            ['slug' => 'contact'],
            [
                'title' => 'Contact Us',
                'is_active' => true,
                'content' => [
                    'hero_title' => 'Get in Touch',
                    'hero_title_ar' => 'اتصل بنا',
                    'hero_subtitle' => 'We would love to hear from you',
                    'hero_subtitle_ar' => 'يسعدنا أن نسمع منك',
                    'address' => '123 Luxury Avenue, Design District',
                    'address_ar' => '١٢٣ شارع الفخامة، منطقة التصميم',
                    'phone' => '+1 (234) 567-890',
                    'email' => 'hello@lumiere.com',
                ]
            ]
        );
    }
}
