import React, { useState } from 'react';
import { Link, usePage, Head } from '@inertiajs/react';
import {
    LayoutDashboard,
    Box,
    Folders,
    ShoppingCart,
    FileText,
    Image as ImageIcon,
    Users,
    Settings,
    LogOut,
    Menu,
    X,
    ChevronRight,
    MessageSquare,
    Link2,
    Mail
} from 'lucide-react';
import { route } from 'ziggy-js';

const SidebarItem = ({ href, icon: Icon, label, active }) => (
    <Link
        href={href}
        className={`flex items-center px-4 py-3 text-sm font-medium transition-colors ${active
            ? 'bg-blue-50 text-blue-600 border-r-4 border-blue-600'
            : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
    >
        <Icon className={`mr-3 h-5 w-5 ${active ? 'text-blue-600' : 'text-gray-400'}`} />
        {label}
        {active && <ChevronRight className="ml-auto h-4 w-4" />}
    </Link>
);

export default function AdminLayout({ children }) {
    const { url, props } = usePage();
    const { auth, settings } = props as any;
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const navigation = [
        { label: 'Dashboard', href: route('admin.dashboard'), icon: LayoutDashboard, active: url === '/admin/dashboard' },
        { label: 'Products', href: route('admin.products.index'), icon: Box, active: url.startsWith('/admin/products') },
        { label: 'Categories', href: route('admin.categories.index'), icon: Folders, active: url.startsWith('/admin/categories') },
        { label: 'Orders', href: route('admin.orders.index'), icon: ShoppingCart, active: url.startsWith('/admin/orders') },
        { label: 'Pages', href: route('admin.pages.index'), icon: FileText, active: url.startsWith('/admin/pages') },
        { label: 'Home Sections', href: route('admin.home-sections.index'), icon: LayoutDashboard, active: url.startsWith('/admin/home-sections') },
        { label: 'Blog', href: route('admin.blog-posts.index'), icon: FileText, active: url.startsWith('/admin/blog-posts') },
        { label: 'Reviews', href: route('admin.reviews.index'), icon: MessageSquare, active: url.startsWith('/admin/reviews') },
        { label: 'Footer Links', href: route('admin.footer-links.index'), icon: Link2, active: url.startsWith('/admin/footer-links') },
        { label: 'Newsletter', href: route('admin.newsletter.index'), icon: Mail, active: url.startsWith('/admin/newsletter') },
        { label: 'Settings', href: route('admin.settings.index'), icon: Settings, active: url.startsWith('/admin/settings') },
        { label: 'Users', href: route('admin.users.index'), icon: Users, active: url.startsWith('/admin/users') },
    ];

    return (
        <div className="min-h-screen bg-gray-100 flex">
            <Head>
                {settings?.favicon && <link rel="icon" type="image/x-icon" href={settings.favicon} />}
            </Head>
            {/* Sidebar */}
            <aside className={`${isSidebarOpen ? 'w-64' : 'w-20'} bg-white shadow-lg transition-all duration-300 flex flex-col fixed inset-y-0 z-50`}>
                <div className="h-16 flex items-center px-6 border-b">
                    <div className={`transition-opacity duration-300 ${!isSidebarOpen && 'opacity-0 hidden'}`}>
                        {settings?.site_logo ? (
                            <img src={settings.site_logo} alt={settings?.site_name || "Admin"} className="h-8 w-auto object-contain" />
                        ) : (
                            <span className="text-xl font-bold text-blue-600">
                                {settings?.site_name || "Luxury Shop"}
                            </span>
                        )}
                    </div>
                    <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="ml-auto text-gray-500 hover:text-gray-700">
                        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
                    </button>
                </div>

                <nav className="flex-1 py-4 overflow-y-auto">
                    {navigation.map((item) => (
                        <SidebarItem key={item.label} {...item} />
                    ))}
                </nav>

                <div className="p-4 border-t">
                    <div className="flex items-center px-4 py-2">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                            {(auth as any).user.name.charAt(0)}
                        </div>
                        {isSidebarOpen && (
                            <div className="ml-3 overflow-hidden">
                                <p className="text-sm font-medium text-gray-900 truncate">{(auth as any).user.name}</p>
                                <p className="text-xs text-gray-500 truncate capitalize">{(auth as any).user.role}</p>
                            </div>
                        )}
                    </div>
                    <Link
                        href={route('logout')}
                        method="post"
                        as="button"
                        className="w-full flex items-center px-4 py-2 mt-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-md transition-colors"
                    >
                        <LogOut className="mr-3 h-5 w-5" />
                        {isSidebarOpen && 'Logout'}
                    </Link>
                </div>
            </aside>

            {/* Main Content */}
            <main className={`flex-1 ${isSidebarOpen ? 'ml-64' : 'ml-20'} transition-all duration-300`}>
                <header className="h-16 bg-white shadow-sm flex items-center px-8 border-b sticky top-0 z-40">
                    <h2 className="text-lg font-semibold text-gray-800">Admin Panel</h2>
                    <div className="ml-auto flex items-center space-x-4">
                        <Link href="/" className="text-sm text-gray-600 hover:text-blue-600">View Shop</Link>
                    </div>
                </header>

                <div className="p-8">
                    {children}
                </div>
            </main>
        </div>
    );
}
