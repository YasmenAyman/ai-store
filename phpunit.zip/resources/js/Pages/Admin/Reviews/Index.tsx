import React from 'react';
import AdminLayout from '@/Layouts/AdminLayout';
import DataTable from '@/Components/DataTable';
import { Button, Badge } from '@/Components/UI';
import {
    CheckCircle,
    Trash2,
    Star,
    ExternalLink,
    MessageSquare
} from 'lucide-react';
import { Head, Link, useForm } from '@inertiajs/react';
import { route } from 'ziggy-js';
import { format } from 'date-fns';

interface Review {
    id: number;
    user_id: number;
    product_id: number;
    rating: number;
    comment: string | null;
    approved: boolean;
    created_at: string;
    user: {
        name: string;
        email: string;
    };
    product: {
        id: number;
        name: string;
    };
}

interface Props {
    reviews: {
        data: Review[];
        links: {
            url: string | null;
            label: string;
            active: boolean;
        }[];
        prev_page_url: string | null;
        next_page_url: string | null;
    };
}

export default function Index({ reviews }: Props) {
    const { post, delete: destroy } = useForm();
    const reviewData = reviews.data || [];

    const handleApprove = (id: number) => {
        if (confirm('Are you sure you want to approve this review?')) {
            post(route('admin.reviews.approve', id));
        }
    };

    const handleDelete = (id: number) => {
        if (confirm('Are you sure you want to delete this review?')) {
            destroy(route('admin.reviews.destroy', id));
        }
    };

    const columns = [
        {
            key: 'user',
            label: 'User',
            render: (_, review) => (
                <div>
                    <div className="font-medium text-gray-900">{review.user.name}</div>
                    <div className="text-xs text-gray-500">{review.user.email}</div>
                </div>
            )
        },
        {
            key: 'product',
            label: 'Product',
            render: (_, review) => (
                <Link
                    href={route('store.show', review.product.id)}
                    className="text-blue-600 hover:underline flex items-center gap-1"
                >
                    {review.product.name}
                    <ExternalLink size={12} />
                </Link>
            )
        },
        {
            key: 'rating',
            label: 'Rating',
            render: (rating) => (
                <div className="flex items-center gap-1">
                    <span className="font-medium">{rating}</span>
                    <Star size={14} className="fill-yellow-400 text-yellow-400" />
                </div>
            )
        },
        {
            key: 'comment',
            label: 'Comment',
            render: (comment) => (
                <p className="max-w-xs truncate" title={comment || ''}>
                    {comment || <span className="italic text-gray-400">No comment</span>}
                </p>
            )
        },
        {
            key: 'approved',
            label: 'Status',
            render: (approved) => (
                <Badge variant={approved ? 'green' : 'yellow'}>
                    {approved ? 'Approved' : 'Pending'}
                </Badge>
            )
        },
        {
            key: 'created_at',
            label: 'Date',
            render: (date) => format(new Date(date), 'MMM d, yyyy')
        }
    ];

    const actions = (review) => (
        <div className="flex justify-end space-x-2">
            {!review.approved && (
                <button
                    onClick={() => handleApprove(review.id)}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors border border-green-100 bg-white"
                    title="Approve"
                >
                    <CheckCircle size={16} />
                </button>
            )}
            <button
                onClick={() => handleDelete(review.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-red-100 bg-white"
                title="Delete"
            >
                <Trash2 size={16} />
            </button>
        </div>
    );

    return (
        <AdminLayout>
            <Head title="Manage Reviews" />

            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Product Reviews</h1>
                    <p className="text-gray-600">Moderate and manage customer feedback.</p>
                </div>
            </div>

            {reviewData.length > 0 ? (
                <>
                    <DataTable
                        columns={columns}
                        data={reviewData}
                        actions={actions}
                    />

                    {reviews.links && reviews.links.length > 3 && (
                        <div className="mt-8 flex justify-center">
                            <div className="flex gap-1">
                                {reviews.links.map((link, i) => (
                                    <Link
                                        key={i}
                                        href={link.url || '#'}
                                        onClick={(e) => !link.url && e.preventDefault()}
                                        className={`px-4 py-2 text-sm font-medium rounded-lg border transition-colors ${link.active
                                                ? 'bg-blue-600 text-white border-blue-600'
                                                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                                            } ${!link.url ? 'opacity-50 cursor-not-allowed' : ''}`}
                                        dangerouslySetInnerHTML={{ __html: link.label }}
                                    />
                                ))}
                            </div>
                        </div>
                    )}
                </>
            ) : (
                <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
                    <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No reviews found</h3>
                    <p className="mt-1 text-sm text-gray-500">Reviews will appear here once customers submit them.</p>
                </div>
            )}
        </AdminLayout>
    );
}
