import React from 'react';
import AdminLayout from '@/Layouts/AdminLayout';
import { Badge, Button } from '@/Components/UI';
import { Head, Link, useForm } from '@inertiajs/react';
import { format } from 'date-fns';
import { ArrowLeft, Printer, Package, Truck, CheckCircle, XCircle } from 'lucide-react';

export default function Show({ order }) {
    const { patch, processing } = useForm();

    const updateStatus = (status) => {
        patch(route('admin.orders.status', order.id), {
            data: { status },
            preserveScroll: true,
        });
    };

    const getStatusVariant = (status) => {
        switch (status) {
            case 'completed': return 'green';
            case 'pending': return 'yellow';
            case 'processing': return 'blue';
            case 'shipped': return 'blue';
            case 'cancelled': return 'red';
            default: return 'gray';
        }
    };

    return (
        <AdminLayout>
            <Head title={`Order #${order.order_number}`} />

            <div className="max-w-5xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center space-x-4">
                        <Link href={route('admin.orders.index')} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                            <ArrowLeft size={20} />
                        </Link>
                        <div>
                            <div className="flex items-center space-x-3">
                                <h1 className="text-2xl font-bold text-gray-900">Order #{order.order_number}</h1>
                                <Badge variant={getStatusVariant(order.status)}>{order.status.toUpperCase()}</Badge>
                            </div>
                            <p className="text-sm text-gray-500">Placed on {format(new Date(order.created_at), 'MMMM dd, yyyy at HH:mm')}</p>
                        </div>
                    </div>
                    <div className="flex space-x-3">
                        <Button variant="secondary" className="flex items-center">
                            <Printer size={18} className="mr-2" /> Print Order
                        </Button>
                        <div className="flex border rounded-lg overflow-hidden">
                            {order.status === 'pending' && (
                                <button onClick={() => updateStatus('processing')} disabled={processing} className="px-4 py-2 bg-blue-600 text-white text-sm font-medium hover:bg-blue-700">Process</button>
                            )}
                            {order.status === 'processing' && (
                                <button onClick={() => updateStatus('shipped')} disabled={processing} className="px-4 py-2 bg-blue-600 text-white text-sm font-medium hover:bg-blue-700">Ship</button>
                            )}
                            {order.status === 'shipped' && (
                                <button onClick={() => updateStatus('completed')} disabled={processing} className="px-4 py-2 bg-green-600 text-white text-sm font-medium hover:bg-green-700">Complete</button>
                            )}
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                        {/* Items */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                            <div className="px-6 py-4 border-b">
                                <h3 className="font-bold text-gray-900">Order Items</h3>
                            </div>
                            <table className="w-full text-left">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Product</th>
                                        <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Price</th>
                                        <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase text-center">Qty</th>
                                        <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase text-right">Total</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {order.items.map((item) => (
                                        <tr key={item.id}>
                                            <td className="px-6 py-4 text-sm text-gray-900 font-medium">{item.product_name}</td>
                                            <td className="px-6 py-4 text-sm text-gray-600">${parseFloat(item.price).toLocaleString()}</td>
                                            <td className="px-6 py-4 text-sm text-gray-600 text-center">{item.quantity}</td>
                                            <td className="px-6 py-4 text-sm text-gray-900 text-right font-bold">${(item.price * item.quantity).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                                <tfoot className="bg-gray-50">
                                    <tr>
                                        <td colSpan="3" className="px-6 py-4 text-right text-sm font-medium text-gray-500">Subtotal</td>
                                        <td className="px-6 py-4 text-right text-sm font-bold text-gray-900">${parseFloat(order.total_amount).toLocaleString()}</td>
                                    </tr>
                                    <tr>
                                        <td colSpan="3" className="px-6 py-4 text-right text-sm font-medium text-gray-500">Shipping</td>
                                        <td className="px-6 py-4 text-right text-sm font-bold text-gray-900">$0.00</td>
                                    </tr>
                                    <tr className="border-t border-gray-200">
                                        <td colSpan="3" className="px-6 py-5 text-right text-lg font-bold text-gray-900">Total</td>
                                        <td className="px-6 py-5 text-right text-2xl font-black text-blue-600">${parseFloat(order.total_amount).toLocaleString()}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div className="space-y-8">
                        {/* Customer Info */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <h3 className="font-bold text-gray-900 mb-4 pb-2 border-b">Customer Details</h3>
                            <div className="space-y-4">
                                <div>
                                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Contact</p>
                                    <p className="text-sm font-medium text-gray-900">{order.user?.name || 'Guest Customer'}</p>
                                    <p className="text-sm text-gray-500">{order.user?.email || 'No email provided'}</p>
                                </div>
                                <div>
                                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Shipping Address</p>
                                    <p className="text-sm text-gray-600 whitespace-pre-wrap">{order.shipping_address}</p>
                                </div>
                            </div>
                        </div>

                        {/* Order Status Timeline */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <h3 className="font-bold text-gray-900 mb-4 pb-2 border-b">Timeline</h3>
                            <div className="space-y-6">
                                <div className="flex items-start space-x-3">
                                    <div className="mt-1 h-2 w-2 rounded-full bg-blue-600 ring-4 ring-blue-50"></div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-900">Order Placed</p>
                                        <p className="text-xs text-gray-500">{format(new Date(order.created_at), 'MMM dd, HH:mm')}</p>
                                    </div>
                                </div>
                                {/* Additional timeline steps could be added here */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
}
