import React from 'react';
import AdminLayout from '@/Layouts/AdminLayout';
import DataTable from '@/Components/DataTable';
import { Button, Badge } from '@/Components/UI';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import { Head, Link } from '@inertiajs/react';
import { route } from 'ziggy-js';

export default function Index({ categories }) {
    const columns = [
        {
            key: 'name',
            label: 'Name',
            render: (value, item) => (
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                        {item.image ? (
                            <img src={item.image} alt={value} className="w-full h-full object-cover" />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-400">
                                <Plus size={16} />
                            </div>
                        )}
                    </div>
                    <div>
                        <div className="font-medium text-gray-900">{value}</div>
                        <div className="text-xs text-gray-500">{item.name_ar}</div>
                    </div>
                </div>
            )
        },
        {
            key: 'slug',
            label: 'Slug',
            render: (slug) => <code className="text-xs bg-gray-100 px-1 py-0.5 rounded text-gray-600">{slug}</code>
        },
        {
            key: 'parent',
            label: 'Parent',
            render: (parent) => parent ? parent.name : <span className="text-gray-400">None</span>
        },
        {
            key: 'is_active',
            label: 'Status',
            render: (isActive) => (
                <Badge variant={isActive ? 'green' : 'gray'}>
                    {isActive ? 'Active' : 'Inactive'}
                </Badge>
            )
        }
    ];

    const actions = (category) => (
        <div className="flex justify-end space-x-2">
            <Link
                href={route('admin.categories.edit', category.id)}
                className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors border border-blue-100 bg-white"
                title="Edit"
            >
                <Edit2 size={16} />
            </Link>
            <Link
                href={route('admin.categories.destroy', category.id)}
                method="delete"
                as="button"
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-red-100 bg-white"
                title="Delete"
                onBefore={() => confirm('Are you sure you want to delete this category?')}
            >
                <Trash2 size={16} />
            </Link>
        </div>
    );

    return (
        <AdminLayout>
            <Head title="Categories" />

            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Categories</h1>
                    <p className="text-gray-600">Organize your products with hierarchical categories.</p>
                </div>
                <Link href={route('admin.categories.create')}>
                    <Button className="flex items-center">
                        <Plus size={18} className="mr-2" />
                        New Category
                    </Button>
                </Link>
            </div>

            <DataTable
                columns={columns}
                data={categories.data || categories}
                actions={actions}
            />
        </AdminLayout>
    );
}
