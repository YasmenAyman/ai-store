import React from 'react';
import AdminLayout from '@/Layouts/AdminLayout';
import { Button, Card } from '@/Components/UI';
import { Head, useForm, Link, router } from '@inertiajs/react';
import { route } from 'ziggy-js';
import { ChevronLeft, Save, Upload, X } from 'lucide-react';

export default function Form({ page = null }) {
    const isEdit = !!page;

    const { data, setData, post: postRequest, processing, errors, setError, clearErrors } = useForm({
        title: page?.title || '',
        slug: page?.slug || '',
        is_active: page?.is_active ?? true,
        hero_bg_file: null,
        content: page?.content || {
            hero_bg: '',
            hero_title: '',
            hero_title_ar: '',
            hero_subtitle: '',
            hero_subtitle_ar: '',
            intro_text: '',
            intro_text_ar: '',
            mission_title: '',
            mission_title_ar: '',
            mission_text: '',
            mission_text_ar: '',
            values_title: '',
            values_title_ar: '',
            value1_title: '',
            value1_title_ar: '',
            value1_desc: '',
            value1_desc_ar: '',
            value2_title: '',
            value2_title_ar: '',
            value2_desc: '',
            value2_desc_ar: '',
            value3_title_ar: '',
            value3_desc: '',
            value3_desc_ar: '',
            address: '',
            address_ar: '',
            phone: '',
            email: '',
        },
    });

    const [heroPreview, setHeroPreview] = React.useState(page?.content?.hero_bg || null);

    const handleHeroBgChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setData('hero_bg_file', file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setHeroPreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isEdit) {
            router.post(route('admin.pages.update', page.id), {
                ...data,
                _method: 'PUT'
            }, {
                forceFormData: true,
                onSuccess: () => { /* Success */ },
                onError: (err) => {
                    clearErrors();
                    Object.keys(err).forEach(key => setError(key as any, err[key]));
                }
            });
        } else {
            postRequest(route('admin.pages.store'));
        }
    };

    const updateContent = (key, value) => {
        setData('content', {
            ...data.content,
            [key]: value
        });
    };

    return (
        <AdminLayout>
            <Head title={isEdit ? `Edit Page: ${page.title}` : 'New Page'} />

            <div className="flex items-center gap-4 mb-8">
                <Link
                    href={route('admin.pages.index')}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                    <ChevronLeft size={20} />
                </Link>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">
                        {isEdit ? 'Edit Page' : 'New Page'}
                    </h1>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="max-w-4xl">
                <div className="grid grid-cols-1 gap-6">
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                        <div className="space-y-4">
                            <h3 className="text-lg font-bold border-b pb-2">General Information</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                                    <input
                                        type="text"
                                        value={data.title}
                                        onChange={e => setData('title', e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                                    />
                                    {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Slug</label>
                                    <input
                                        type="text"
                                        value={data.slug}
                                        onChange={e => setData('slug', e.target.value)}
                                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                                    />
                                    {errors.slug && <p className="text-red-500 text-xs mt-1">{errors.slug}</p>}
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    id="is_active"
                                    checked={data.is_active}
                                    onChange={e => setData('is_active', e.target.checked)}
                                    className=" rounded text-blue-600 focus:ring-blue-500"
                                />
                                <label htmlFor="is_active" className="text-sm font-medium text-gray-700">Active</label>
                            </div>
                        </div>
                    </div>

                    {(data.slug === 'about' || data.slug === 'contact') && (
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="p-6 space-y-6">
                                <h3 className="text-lg font-bold border-b pb-2">
                                    {data.slug === 'about' ? 'About Page Content' : 'Contact Page Content'}
                                </h3>

                                {/* Hero Section */}
                                <div className="space-y-4 pt-2">
                                    <h4 className="font-semibold text-blue-600">Hero Section</h4>
                                    <div className="grid grid-cols-1 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-2">Hero Background Image</label>
                                            <div className="flex flex-col gap-4">
                                                {heroPreview && (
                                                    <div className="relative w-full h-48 rounded-xl overflow-hidden border border-gray-200 group">
                                                        <img src={heroPreview} className="w-full h-full object-cover" alt="Preview" />
                                                        <button
                                                            type="button"
                                                            onClick={() => { setHeroPreview(null); setData('hero_bg_file', null); }}
                                                            className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                                        >
                                                            <X size={14} />
                                                        </button>
                                                    </div>
                                                )}
                                                <div className="relative">
                                                    <input
                                                        type="file"
                                                        onChange={handleHeroBgChange}
                                                        className="hidden"
                                                        id="hero_bg_file"
                                                        accept="image/*"
                                                    />
                                                    <label
                                                        htmlFor="hero_bg_file"
                                                        className="flex flex-col items-center justify-center w-full min-h-[100px] border-2 border-dashed border-gray-200 rounded-xl hover:border-blue-400 hover:bg-blue-50/30 transition-all cursor-pointer group"
                                                    >
                                                        <Upload className="w-8 h-8 text-gray-300 group-hover:text-blue-400 mb-2" />
                                                        <span className="text-sm font-medium text-gray-500 group-hover:text-blue-400">
                                                            {heroPreview ? 'Change Background' : 'Upload Background'}
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                            {errors.hero_bg_file && <p className="text-xs text-red-500 mt-1">{errors.hero_bg_file}</p>}
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Hero Title (EN)</label>
                                            <input type="text" value={data.content.hero_title} onChange={e => updateContent('hero_title', e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Hero Title (AR)</label>
                                            <input type="text" value={data.content.hero_title_ar} onChange={e => updateContent('hero_title_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg text-right" dir="rtl" />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Hero Subtitle (EN)</label>
                                            <textarea value={data.content.hero_subtitle} onChange={e => updateContent('hero_subtitle', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-20" />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Hero Subtitle (AR)</label>
                                            <textarea value={data.content.hero_subtitle_ar} onChange={e => updateContent('hero_subtitle_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-20 text-right" dir="rtl" />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Intro Text (EN)</label>
                                            <textarea value={data.content.intro_text} onChange={e => updateContent('intro_text', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-32" />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-medium text-gray-500 mb-1">Intro Text (AR)</label>
                                            <textarea value={data.content.intro_text_ar} onChange={e => updateContent('intro_text_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-32 text-right" dir="rtl" />
                                        </div>
                                    </div>
                                </div>

                                {data.slug === 'contact' && (
                                    <div className="space-y-4 pt-4 border-t">
                                        <h4 className="font-semibold text-blue-600">Contact Details</h4>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Address (EN)</label>
                                                <input type="text" value={data.content.address} onChange={e => updateContent('address', e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Address (AR)</label>
                                                <input type="text" value={data.content.address_ar} onChange={e => updateContent('address_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg text-right" dir="rtl" />
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Phone Number</label>
                                                <input type="text" value={data.content.phone} onChange={e => updateContent('phone', e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Email Address</label>
                                                <input type="text" value={data.content.email} onChange={e => updateContent('email', e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {data.slug === 'about' && (
                                    <>
                                        {/* Mission Section */}
                                        <div className="space-y-4 pt-4 border-t">
                                            <h4 className="font-semibold text-blue-600">Mission Section</h4>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-500 mb-1">Mission Title (EN)</label>
                                                    <input type="text" value={data.content.mission_title} onChange={e => updateContent('mission_title', e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                                </div>
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-500 mb-1">Mission Title (AR)</label>
                                                    <input type="text" value={data.content.mission_title_ar} onChange={e => updateContent('mission_title_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg text-right" dir="rtl" />
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-500 mb-1">Mission Text (EN)</label>
                                                    <textarea value={data.content.mission_text} onChange={e => updateContent('mission_text', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-32" />
                                                </div>
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-500 mb-1">Mission Text (AR)</label>
                                                    <textarea value={data.content.mission_text_ar} onChange={e => updateContent('mission_text_ar', e.target.value)} className="w-full px-3 py-2 border rounded-lg h-32 text-right" dir="rtl" />
                                                </div>
                                            </div>
                                        </div>

                                        {/* Values */}
                                        <div className="space-y-4 pt-4 border-t">
                                            <h4 className="font-semibold text-blue-600">Values Section</h4>
                                            <div className="grid grid-cols-1 gap-6">
                                                {[1, 2, 3].map(i => (
                                                    <div key={i} className="p-4 bg-gray-50 rounded-lg space-y-3">
                                                        <h5 className="text-sm font-bold">Value {i}</h5>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div>
                                                                <label className="block text-xs font-medium text-gray-500 mb-1">Title (EN)</label>
                                                                <input type="text" value={data.content[`value${i}_title`]} onChange={e => updateContent(`value${i}_title`, e.target.value)} className="w-full px-3 py-2 border rounded-lg" />
                                                            </div>
                                                            <div>
                                                                <label className="block text-xs font-medium text-gray-500 mb-1">Title (AR)</label>
                                                                <input type="text" value={data.content[`value${i}_title_ar`]} onChange={e => updateContent(`value${i}_title_ar`, e.target.value)} className="w-full px-3 py-2 border rounded-lg text-right" dir="rtl" />
                                                            </div>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div>
                                                                <label className="block text-xs font-medium text-gray-500 mb-1">Description (EN)</label>
                                                                <textarea value={data.content[`value${i}_desc`]} onChange={e => updateContent(`value${i}_desc`, e.target.value)} className="w-full px-3 py-2 border rounded-lg h-20" />
                                                            </div>
                                                            <div>
                                                                <label className="block text-xs font-medium text-gray-500 mb-1">Description (AR)</label>
                                                                <textarea value={data.content[`value${i}_desc_ar`]} onChange={e => updateContent(`value${i}_desc_ar`, e.target.value)} className="w-full px-3 py-2 border rounded-lg h-20 text-right" dir="rtl" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                    )}

                    <div className="flex justify-end gap-3">
                        <Link href={route('admin.pages.index')}>
                            <Button variant="outline" type="button">Cancel</Button>
                        </Link>
                        <Button type="submit" disabled={processing} className="flex items-center">
                            <Save size={18} className="mr-2" />
                            {isEdit ? 'Update Page' : 'Create Page'}
                        </Button>
                    </div>
                </div>
            </form>
        </AdminLayout>
    );
}
