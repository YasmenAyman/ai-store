import { Layout } from "@/Components/layout/Layout";
import { Hero } from "@/Components/home/Hero";
import { Categories } from "@/Components/home/Categories";
import { Featured } from "@/Components/home/Featured";
import { PromoBanner } from "@/Components/home/PromoBanner";
import { CTAHome } from "@/Components/home/CTAHome";
import { BlogPreview } from "@/Components/home/BlogPreview";
import { Testimonials } from "@/Components/home/Testimonials";

const Index = ({ hero, categories, featuredProducts, bestSellers, recentPosts, testimonials }: {
  hero?: any,
  categories: any[],
  featuredProducts?: any[],
  bestSellers?: any[],
  recentPosts?: any[],
  testimonials?: any[]
}) => {
  return (
    <Layout>
      <Hero data={hero} />
      <Categories data={categories} />
      <Featured data={featuredProducts} bestSellers={bestSellers} />
      <PromoBanner />
      <CTAHome />
      <BlogPreview posts={recentPosts} />
      <Testimonials reviews={testimonials || []} />
    </Layout>
  );
};

export default Index;
