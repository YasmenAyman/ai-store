import { useState } from "react";
import { Link, usePage } from "@inertiajs/react";
import { Layout } from "@/Components/layout/Layout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import { useFavorites } from "@/contexts/FavoritesContext";
import { ProductCard } from "@/Components/shared/ProductCard";
import { Button } from "@/Components/ui/button";
import { Badge } from "@/Components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/Components/ui/tabs";
import { Heart, Minus, Plus, ArrowLeft, ArrowRight, MessageSquare } from "lucide-react";
import { StarRatingDisplay } from "@/Components/shared/StarRatingDisplay";
import { ReviewForm } from "@/Components/shared/ReviewForm";
import { ReviewList } from "@/Components/shared/ReviewList";
import { route } from "ziggy-js";

const ProductDetails = ({ product, relatedProducts }: { product: any, relatedProducts: any[] }) => {
  const { language, t } = useLanguage();
  const { auth } = usePage().props as any;
  const { addItem } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();
  const [quantity, setQuantity] = useState(1);

  const related = relatedProducts || [];

  const name = language === "ar" ? (product.name_ar || product.name) : product.name;
  const description = language === "ar" ? (product.description_ar || product.description) : product.description;
  const liked = isFavorite(product.id);
  const BackArrow = language === "ar" ? ArrowRight : ArrowLeft;

  const primaryImage = product.images?.find((img: any) => img.is_primary)?.image_path
    || product.images?.[0]?.image_path
    || "/assets/placeholder.jpg";

  return (
    <Layout>
      <div className="container py-8 md:py-16">
        {/* Breadcrumb */}
        <Link
          href="/store"
          className="mb-8 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <BackArrow className="h-4 w-4" />
          {t.product.backToStore}
        </Link>

        {/* Product Section */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-12 mt-6">
          {/* Image */}
          <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
            <img
              src={primaryImage}
              alt={name}
              className="h-full w-full object-cover"
            />
            {product.compare_at_price && (
              <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground text-sm px-3 py-1">
                -{Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)}%
              </Badge>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col gap-5">
            <div>
              <h1 className="text-2xl md:text-3xl font-serif font-bold leading-tight">
                {name}
              </h1>

              {/* Rating */}
              <div className="mt-3 flex items-center gap-2">
                <StarRatingDisplay rating={product.average_rating || 0} size={18} />
                <span className="text-sm text-muted-foreground">
                  {product.average_rating?.toFixed(1) || "0.0"} ({product.total_reviews || 0} {t.product.reviews.toLowerCase()})
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-foreground">
                ${product.price}
              </span>
              {product.compare_at_price && (
                <span className="text-lg text-muted-foreground line-through">
                  ${product.compare_at_price}
                </span>
              )}
            </div>

            {/* Stock */}
            <Badge
              variant={product.stock > 0 ? "default" : "secondary"}
              className={`w-fit ${product.stock > 0 ? "bg-green-600/10 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800" : ""}`}
            >
              {product.stock > 0 ? t.product.inStock : t.product.outOfStock}
            </Badge>

            {/* Description excerpt */}
            <p className="text-muted-foreground leading-relaxed">{description}</p>

            {/* Quantity + Add to Cart */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mt-2">
              <div className="flex items-center border border-border rounded-md">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-2.5 hover:bg-muted transition-colors"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="px-5 py-2.5 min-w-[3rem] text-center font-medium border-x border-border">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="px-3 py-2.5 hover:bg-muted transition-colors"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              <Button
                size="lg"
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={product.stock <= 0}
                onClick={() => {
                  for (let i = 0; i < quantity; i++) {
                    addItem({ id: product.id, name, price: product.price, image: primaryImage });
                  }
                }}
              >
                {t.product.addToCart}
              </Button>

              <button
                onClick={() => toggleFavorite(product.id)}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-border hover:bg-muted transition-colors"
                aria-label="Toggle favorite"
              >
                <Heart
                  className={`h-5 w-5 transition-colors ${liked ? "fill-accent text-accent" : "text-foreground/60"}`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="description" className="mt-16">
          <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0 h-auto">
            <TabsTrigger
              value="description"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-6 pb-3 font-serif"
            >
              {t.product.description}
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-6 pb-3 font-serif"
            >
              {t.product.reviews} ({product.total_reviews || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="pt-6">
            <p className="max-w-2xl leading-relaxed text-muted-foreground whitespace-pre-line">
              {description}
            </p>
          </TabsContent>

          <TabsContent value="reviews" className="pt-8 space-y-12">
            <div className="grid lg:grid-cols-5 gap-12">
              <div className="lg:col-span-3 space-y-8">
                <div className="flex items-center gap-4">
                  <h2 className="text-2xl font-serif font-bold">{(t as any).reviews.title}</h2>
                  <Badge variant="outline" className="px-3">{product.total_reviews} {(t as any).reviews.reviewsCount}</Badge>
                </div>
                <ReviewList reviews={product.reviews || []} />
              </div>

              <div className="lg:col-span-2">
                <div className="sticky top-24 space-y-6">
                  {auth?.user ? (
                    <>
                      <div className="space-y-2">
                        <h3 className="text-xl font-serif font-semibold">{(t as any).reviews.writeReview}</h3>
                        <p className="text-sm text-muted-foreground">{(t as any).reviews.shareThoughts}</p>
                      </div>
                      <ReviewForm productId={product.id} />
                    </>
                  ) : (
                    <div className="rounded-xl border border-border/50 bg-muted/30 p-8 text-center space-y-4">
                      <div className="mx-auto w-12 h-12 bg-background rounded-full flex items-center justify-center">
                        <MessageSquare className="w-6 h-6 text-muted-foreground" />
                      </div>
                      <div className="space-y-1">
                        <p className="font-medium text-foreground">{(t as any).reviews.wantToShare}</p>
                        <p className="text-sm text-muted-foreground">{(t as any).reviews.mustBeLoggedIn}</p>
                      </div>
                      <Button asChild variant="outline" className="w-full">
                        <Link href={route("login")}>{(t as any).reviews.loginToReview}</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        {related.length > 0 && (
          <section className="mt-20">
            <h2 className="text-2xl font-serif font-bold mb-8">{t.product.related}</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </div>
    </Layout>
  );
};

export default ProductDetails;

